const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const path = require('path')

const PatientRoute = require('./routes/patient');
const LoginController = require("./controllers/LoginController");
const PaymentController = require("./controllers/PaymentController");

mongoose.connect('mongodb://localhost:27017/goodhealthDb', {useNewUrlParser:true,useUnifiedTopology:true});
const db = mongoose.connection

db.on('error',(error)=>{
  console.log(error);
});

db.once('open',()=>{
  console.log("Connected to db")
})

const app = express();
app.use(bodyParser.json());

const PORT = process.env.PORT || 3000
app.get('/',function(req,res){
  res.sendFile('index.html',{root:path.join(__dirname)})
})

app.get('/register',function(req,res){
  res.sendFile('register.html',{root:path.join(__dirname)})
})

app.listen(PORT,()=>{
  console.log("Server is up and running")
})

app.use('/api/patient', PatientRoute)
app.use('/student', StudentRoute)
app.use('/api/payment',PaymentController)