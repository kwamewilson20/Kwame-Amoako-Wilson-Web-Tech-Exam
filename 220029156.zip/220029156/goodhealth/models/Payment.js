const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const paymentSchema = new Schema({
    patientName:{
        type:String
    },
    paymentDate:{
        type:Date
    },
    amount:{
        type:Number
    },
    balance:{
        type:Number
    }
}, {timestamps:true});

const Payment = mongoose.model('Payment',paymentSchema);
module.exports = Payment;