const router = require("express").Router();
const Payment = require("../models/Payment");

router.post("/make-payment",async (req, resp)=>{
    const payment = await Payment.create(req.body);
    return resp.status(201).json({
        payment
    })
});


router.get("/get-payment", async (req, resp)=>{
    const payments = await Payment.find({});

    return resp.status(200).json({
        payments
    })
});


router.put('/update', async (req, resp) => {

});


router.delete('/delete', async(req, resp) => {
    const oldData = await Payment.findById(req.query.id);
    const deleted = await Payment.delete(oldData);

    resp.status(200).json({
        status:"Item deleted successfully"
    })
});



module.exports =router;