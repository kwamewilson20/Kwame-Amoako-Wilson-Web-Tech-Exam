const Student = require('../models/Student');

// get list of students
const index = (req, res,next) =>{
    Student.find()
    .then(response => {
        res.json({
            response
        })
    })
    .catch(error =>{
        res.json({
            message : 'An error occurred'
        })
    })
}

const show = (req,res,next)=>{
    let studentId = req.body.studentId;
    Student.findById(studentId)
    .then(response => {
        res.json({
            response
        })
    })
    .catch(error=>{
        res.json({
            message : 'An error occurred'
        })
    })
};

const store =(req, res,next)=>{
    let student = new Student({
        firstName:req.body.firstName,
        lastName:req.body.lastName,
        dateOfBirth:req.body.dateOfBirth,
        contact:req.body.contact,
    })
    student.save()
    .then(response => {
        res.json({
            message:"Student saved successfully"
        })
    })
    .catch(error=>{
        res.json({
            message:"An error occurred"
        })
    })
};

const update =(req, res,next)=>{

    let studentId = req.body.studentId;

    let studentUpdateData = new Student({
        firstName:req.body.firstName,
        lastName:req.body.lastName,
        dateOfBirth:req.body.dateOfBirth,
        contact:req.body.contact,
    })

    Student.findByIdAndUpdate(studentId,{$set:studentUpdateData})
    .then(() => {
        res.json({
            message:"Student updated successfully"
        })
    })
    .catch(error=>{
        res.json({
            message:"An error occurred"
        })
    })
};

const destroy =(req, res,next)=>{

    let studentId = req.body.studentId;

    Student.findOneAndRemove(studentId)
    .then(() => {
        res.json({
            message:"Student deleted successfully"
        })
    })
    .catch(error=>{
        res.json({
            message:"An error occurred"
        })
    })
};

module.exports = {
    index, show, store, update, destroy
}