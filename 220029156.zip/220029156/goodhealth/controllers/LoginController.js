const router = require("express").Router();
const User = require("../models/User");


router.post("/login", async (req, resp) => {
    const {email, password} = req.body;
    let user = await  User.findOne({email});
    if(!user){
    //    404
        return resp.status(404).json({
            status:"User with email not found"
        })
    }
    if(user.password !== password){
    //    401
        return resp.status(401).json({
            status:"invalid user credentials"
        })
    }

    return resp.status(200).json({
        user
    })
});



module.exports = router;