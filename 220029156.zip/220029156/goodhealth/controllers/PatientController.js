const Patient = require('../models/Patient');

// show list of patients
const index = (req, res,next) =>{
    Patient.find()
    .then(response => {
        res.json({
            response
        })
    })
    .catch(error =>{
        res.json({
            message : 'An error occurred'
        })
    })
}

const show = (req,res,next)=>{
    let patientId = req.body.patientId;
    Patient.findById(patientId)
    .then(response => {
        res.json({
            response
        })
    })
    .catch(error=>{
        res.json({
            message : 'An error occurred'
        })
    })
};

const store =(req, res,next)=>{
    let patient = new Patient({
        firstName:req.body.firstName,
        lastName:req.body.lastName,
        dateOfBirth:req.body.dateOfBirth,
        phoneNumber:req.body.phoneNumber,
        address:req.body.address,
        emergencyContact:req.body.emergencyContact,
    })
    patient.save()
    .then(response => {
        res.json({
            message:"Patient saved successfully"
        })
    })
    .catch(error=>{
        res.json({
            message:"An error occurred"
        })
    })
};

const update =(req, res,next)=>{

    let patientId = req.body.patientId;

    let patientUpdateData = new Patient({
        firstName:req.body.firstName,
        lastName:req.body.lastName,
        dateOfBirth:req.body.dateOfBirth,
        phoneNumber:req.body.phoneNumber,
        address:req.body.address,
        emergencyContact:req.body.emergencyContact,
    })

    Patient.findByIdAndUpdate(patientId,{$set:patientUpdateData})
    .then(() => {
        res.json({
            message:"Patient updated successfully"
        })
    })
    .catch(error=>{
        res.json({
            message:"An error occurred"
        })
    })
};

const destroy =(req, res,next)=>{

    let patientId = req.body.patientId;

    Patient.findOneAndRemove(patientId)
    .then(() => {
        res.json({
            message:"Patient deleted successfully"
        })
    })
    .catch(error=>{
        res.json({
            message:"An error occurred"
        })
    })
};

module.exports = {
    index, show, store, update, destroy
}