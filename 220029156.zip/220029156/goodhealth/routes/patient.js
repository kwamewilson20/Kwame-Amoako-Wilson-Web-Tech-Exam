const express = require('express')

const router = express.Router();

const PatientController = require('../controllers/PatientController');

router.get("/",PatientController.index)
router.post("/show",PatientController.show)
router.post("/store",PatientController.store)
router.post("/update",PatientController.update)
router.post("/delete",PatientController.destroy)

module.exports = router