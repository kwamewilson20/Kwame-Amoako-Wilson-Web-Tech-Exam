const Sequelize = require('sequelize');
const TodoModel = require('./models/Todo');
const express = require('express')

const sequelize = new Sequelize('DB_A2A9C5_db', 'DB_A2A9C5_db_admin', 'testpass@word123', {
  host: 'sql6009.site4now.net',
  dialect: 'mysql',
});

const Todo = TodoModel(sequelize, Sequelize);

sequelize.sync().then(() => {
  console.log(`Users db and user table have been created`);
});

module.exports = Todo;