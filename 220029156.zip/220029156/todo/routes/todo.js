const express = require('express')

const router = express.Router();

const TodoController = require('../controllers/TodoController');

router.get("/get",TodoController.index)
router.post("/post",TodoController.store)
router.post("/delete",TodoController.destroy)

module.exports = router