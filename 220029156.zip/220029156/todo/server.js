const express = require('express');
const bodyParser = require('body-parser');
const app = express();

const API_PORT = process.env.API_PORT || 3001;
const TodoRoute = require('./routes/todo')

app.use(bodyParser.json());



app.listen(API_PORT, () => console.log(`Listening on port ${API_PORT}`));

app.use('/todo', TodoRoute)