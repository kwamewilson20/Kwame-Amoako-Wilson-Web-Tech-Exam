const Todo = require('../sequelize');

// get list of todos
const index = (req, res,next) =>{
    Todo.findAll()
    .then(response => {
        res.json({
            response
        })
    })
    .catch(error =>{
        res.json({
            message : 'An error occurred'
        })
    })
}


const store =(req, res,next)=>{
    let todo = new Todo({
        title:req.body.title,
        description:req.body.description,
    
    })
    todo.create()
    .then(response => {
        res.json({
            message:"Todo saved successfully"
        })
    })
    .catch(error=>{
        res.json({
            message:"An error occurred"
        })
    })
};

const destroy =(req, res,next)=>{

    let todoId = req.body.todoId;

    
    Todo.findOneAndRemove(todoId)
    .then(() => {
        res.json({
            message:"Todo deleted successfully"
        })
    })
    .catch(error=>{
        res.json({
            message:"An error occurred"
        })
    })
};




module.exports = {
    index,  store, destroy
}